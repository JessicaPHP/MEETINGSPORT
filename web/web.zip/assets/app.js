// require jQuery normally
//const $ = require('/node_modules/jquery');

// create global $ and jQuery variables
//global.$ = global.jQuery = $;